 page = Client.LoadPage("page_0")

function ResetPage()
    page.Destroy()
end

function SelecteCharacter(chracterID,jobID)
    Client.FireEvent("Selecte",Client.myPlayerUnit.id,chracterID,jobID)
    LoadReadyPage()
end

-- 캐릭터 선택 레이아웃 페이지 출력 및 선택된 캐릭터 데이터 변경
function SelecteCharacterPage(chracterID,jobID,imagePath)
    page.Destroy();
    page = Client.LoadPage("page_1")
    local tbHP = page.GetControl("tbHP")
    --local imgHP = page.GetControl("imgHP")
    local tbDamage =  page.GetControl("tbDamage")
    --local imgDamage =  page.GetControl("imgDamage")
    local btnBack =  page.GetControl("btnBack")
    --local imgBack =  page.GetControl("imgBack")
    local btnSelecte = page.GetControl("btnSelecte")

    local tbChrName =  page.GetControl("tbChrName")
    local tbChrInfo = page.GetControl("tbChrInfo")
    local imgCharacter = page.GetControl("imgCharacter")

    -- 캐릭터 정보 입력
    local chrData = Client.GetCharacter(chracterID)
    tbChrName.text = chrData.name
    tbChrInfo.text = chrData.memo

    -- 직업 정보 입력
    local jobData = Client.GetJob(jobID)
    tbHP.text = jobData.maxHPs[1]
    tbDamage.text = jobData.attacks[1]

    --버튼 기능 연결
    btnBack.onClick.Add(LoadReadyPage)
    btnSelecte.onClick.Add(function() SelecteCharacter(chracterID,jobID) end )
    imgCharacter.image = imagePath;

end

-- 준비 대기 버튼 설정
function Ready(button)
if button.text == "준비" then
    button.text = "대기중"
    Client.FireEvent("Ready",Client.myPlayerUnit.id)
else
    button.text = "준비"
    Client.FireEvent("CancelReady",Client.myPlayerUnit.id)
end

end

function LoadReadyPage()
    page.Destroy()
    page = Client.LoadPage("page_3")
    local btnReady = page.GetControl("btnReady")
    btnReady.onClick.Add(function() Ready(btnReady) end)
end
