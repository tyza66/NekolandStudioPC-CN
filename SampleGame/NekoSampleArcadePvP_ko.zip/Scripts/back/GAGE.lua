HPMPbg = Image("Pictures/HP_MP_bg.png", Rect(84, 7, 140, 30)) -- HP, MP 게이지 뒷배경
HP = Image("Pictures/HP.png", Rect(89, 10, 130, 10)) -- HP 게이지 이미지
MP = Image("Pictures/MP.png", Rect(89, 22, 130, 10)) -- MP 게이지 이미지
HPtxt = Text("",Rect(100, -1, 100, 30)) -- HP 텍스트
MPtxt = Text("",Rect(100, 12, 100, 30)) -- MP 텍스트

HPMPbg.showOnTop = true -- HP, MP 게이지 뒷배경을 가장 위로 올리기
HP.showOnTop = true -- HP 게이지를 가장 위로 올리기
MP.showOnTop = true -- MP 게이지를 가장 위로 올리기
HPtxt.showOnTop = true -- HP 텍스트를 가장 위로 올리기
MPtxt.showOnTop = true --MP 텍스트를 가장 위로 올리기

HPtxt.textSize = 9 -- HP 텍스트 크기를 10으로 설정
MPtxt.textSize = 9 -- MP 텍스트 크기를 10으로 설정

function HPMPBar()
 maxHP = math.floor(Client.myPlayerUnit.hp / Client.myPlayerUnit.maxHP * 100)
 maxMP = math.floor(Client.myPlayerUnit.mp / Client.myPlayerUnit.maxMP * 100) 
 Thp = 135 * maxHP / 100
 Tmp = 135 * maxMP / 100
 HP.rect = Rect(87, 10, Thp , 10)
 MP.rect = Rect(87, 22, Tmp , 10)
 HPtxt.text = Client.myPlayerUnit.hp.." / "..Client.myPlayerUnit.maxHP
 MPtxt.text = Client.myPlayerUnit.mp.." / "..Client.myPlayerUnit.maxMP
end

Client.onTick.Add(HPMPBar,1) -- 1프레임마다 HPMPBar 함수 실행.