Server.sayCallback = function(player, text, sayType) 
    if sayType == 1 then -- 전체채팅일 경우 챗 차단
    --unit.SendCenterLabel("근처 채팅으로 바꿔주셔야 채팅 이용이 가능합니다.")
    player.unit.SendCenterLabel("근처 채팅으로 바꿔주셔야 채팅 이용이 가능합니다.\n 채팅 설정은 하단에서 설정 가능합니다.")
    return false
    if sayType == 2 then -- 전체채팅일 경우 챗 차단
        --unit.SendCenterLabel("근처 채팅으로 바꿔주셔야 채팅 이용이 가능합니다.")
        player.unit.SendCenterLabel("근처 채팅으로 바꿔주셔야 채팅 이용이 가능합니다.\n 채팅 설정은 하단에서 설정 가능합니다.")
        return false  
    else -- 그외의경우 정상적으로 채팅함 
    return true 
    end 
    end 