--[[
-- 당기기
-- a : 당기는 유닛
-- b : 끌려오는 유닛
]]--
function PullTarget(a, b)
	local d = 0		-- a와 b 의 거리
	
	if a.dirX ~= 0 and a.dirY ~= 0 then
		-- 8 방향 기준 대각선일 때
		b.dirX = a.dirX * -1
		b.dirY = a.dirY * -1
		x = a.x - b.x
		y = math.abs(a.y) - math.abs(b.y)
		
		x = x*x
		y = y*y
		
		d = math.sqrt(x+y)
		
	elseif a.dirX ~= 0 then
		-- 좌 또는 우 방향일 때
		b.dirX = a.dirX * -1
		b.dirY = a.dirY * -1
		d = a.x - b.x
	else
		-- 상 또는 하 방향일 때
		b.dirX = a.dirX * -1
		b.dirY = a.dirY * -1
		d = math.abs(a.y) - math.abs(b.y)
	end
	
	if d > 0 then
		d = d * -1
	end
	
	-- 당길 때 유닛이 겹치지 않게 유닛 충돌 범위를 계산하여 더해줌.
	-- 더하는 이유는 d 가 음수이기 때문에 더해야 수치가 줄어듬.
	d = d + 32

	-- 플레이어 유닛 위치 정보 갱신
	a.SendUpdated(true)
	b.SendUpdated(true)
	
	-- 넉백 실시
	b.MakeKnockback(d, 0.1)
end