function onUnitDead(target, attacker) --target은 죽은자, attacker는 공격자
   if (target.type==0 and attacker.type==0) then --PlayerUnit일 경우
        target.field.SendCenterLabel (target.name .. '님이 사망하였습니다.')
  if attacker then
       attacker.StartGlobalEvent(1)
  if target then
          target.StartGlobalEvent(2)
      end
end
end
end
Server.onUnitDead.Add(onUnitDead) -- Server.onUnitDead에 onUnitDead함수를 추가한다...