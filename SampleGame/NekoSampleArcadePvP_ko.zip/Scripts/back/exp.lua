﻿exp_bot = Image("Pictures/exp_bot.png", Rect(0, Client.height-10, 800, 10)) --게이지 바닥 이미지
exp_guage = Image("Pictures/exp.png", Rect(0, Client.height-10, 800, 10)) --게이지 이미지

exp_text1 = Text("",Rect(Client.width-425-1, Client.height-35, 200, 50))--텍스트 좌측 외곽선
exp_text2 = Text("",Rect(Client.width-425, Client.height-35-1, 200, 50))--텍스트 상측 외곽선
exp_text3 = Text("",Rect(Client.width-425+1, Client.height-35, 200, 50))--텍스트 우측 외곽선
exp_text4 = Text("",Rect(Client.width-425, Client.height-35+1, 200, 50))--텍스트 하측 외곽선
exp_text5 = Text("",Rect(Client.width-425, Client.height-35, 200, 50))--텍스트

exp_text1.textSize = 15 --텍스트 좌측 사이즈
exp_text2.textSize = 15 --텍스트 상측 사이즈
exp_text3.textSize = 15 --텍스트 우측 사이즈
exp_text4.textSize = 15 --텍스트 하측 사이즈
exp_text5.textSize = 15 --텍스트 사이즈

exp_text1.color = Color(0,0,0) --텍스트 좌측 외곽선 색상
exp_text2.color = Color(0,0,0) --텍스트 상측 외곽선 색상
exp_text3.color = Color(0,0,0) --텍스트 우측 외곽선 색상
exp_text4.color = Color(0,0,0) --텍스트 하측 외곽선 색상


function Exps() --실행 함수
 mexp = math.floor(Client.myPlayerUnit.exp / Client.myPlayerUnit.maxEXP * 100) --퍼센티지 변환
 Texp = Client.width * mexp / 100 --퍼센티지 만큼 exp게이지 이미지를 보여주기위한 Rect가로크기 설정

if Client.myPlayerUnit.maxEXP == 0 then --캐릭터 레벨이 최대치인 경우
 exp_text1.text = "최대 레벨 달성" --텍스트 좌측 출력
 exp_text2.text = "최대 레벨 달성" --텍스트 상측 출력
 exp_text3.text = "최대 레벨 달성" --텍스트 우측 출력
 exp_text4.text = "최대 레벨 달성" --텍스트 하측 출력
 exp_text5.text = "최대 레벨 달성" --텍스트 출력
else
 exp_text1.text = Client.myPlayerUnit.exp.."/"..Client.myPlayerUnit.maxEXP.." ("..mexp.."%)" --텍스트 좌측 출력
 exp_text2.text = Client.myPlayerUnit.exp.."/"..Client.myPlayerUnit.maxEXP.." ("..mexp.."%)" --텍스트 상측 출력
 exp_text3.text = Client.myPlayerUnit.exp.."/"..Client.myPlayerUnit.maxEXP.." ("..mexp.."%)" --텍스트 우측 출력
 exp_text4.text = Client.myPlayerUnit.exp.."/"..Client.myPlayerUnit.maxEXP.." ("..mexp.."%)" --텍스트 하측 출력
 exp_text5.text = Client.myPlayerUnit.exp.."/"..Client.myPlayerUnit.maxEXP.." ("..mexp.."%)" --텍스트 출력
end

 exp_guage.rect = Rect(0, Client.height-10, Texp, 10) --퍼센티지 만큼 exp게이지 이미지 출력
end --함수의 끝

Client.onTick.Add(Exps,30) --지정된 프레임마다 함수 실행