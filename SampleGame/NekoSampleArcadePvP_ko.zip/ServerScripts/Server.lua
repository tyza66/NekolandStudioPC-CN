-- 유저 찾기
function FindUser(id)
    for i,n in pairs(Server.players) do
        if(n.unit.id == id) then
            return n.unit;
        end
    end
end

-- 캐릭터 선택 행동
Server.GetTopic("Selecte").Add(
    function(id,chr,job)
        local user = FindUser(id)
        user.characterID = chr
        user.SetVar(2,chr)
        user.job = job
        user.SetVar(3,job)
        user.SendUpdated()
        --ChangeChrAndJob(id,chr,job) 
    end)

-- 레디,취소 수정
Server.GetTopic("Ready").Add(
    function(id) 
        local user = FindUser(id)
        print(user.name)
        user.SetVar(1,1)
        -- user.SendUpdated()
        if StartGame() == true then
            --1번만 실행하기위한 설정
            user.StartGlobalEvent(1)
        end
    end)
Server.GetTopic("CancelReady").Add(
    function(id) 
        local user = FindUser(id)
        user.SerVar(1,0) 
    end)

-- 게임시작을위해서 변수값을 설정
function StartGame()
    print("StartGame")
    for i,n in pairs(Server.players) do
        if(n.unit.GetVar(1) == 0) then
            return false;
        end
    end
    return true
end

--사망시 유령으로 변경 킬/데스 기록
Server.onUnitDead.Add(
    function(me,attacker)
        -- 내가사망시에는 유령으로 변경 및 데스 증가
        me.StartGlobalEvent(2)
        me.SetVar(5,me.GetVar(5) + 1)
        -- 무적버프 부여
        me.AddBuff(0,attacker)
        print(me.name)
        -- 상대방은 킬 증가
        if me.type == 0 then
            attacker.SetVar(4,attacker.GetVar(4) + 1)
        end
    end
)

function FirstAttack(enemy,ai,event,data)
    if (event == AI_UPDATE) then -- 2초마다 실행되는 이벤트
    
        --맵에 플레이어가 하나도 없으면 null 세팅
        if enemy.field.playerCount <=0 then
            ai.SetTargetUnit(nil)
            
        -- 타겟이 없거나, 기존 타겟이던 unit이 맵을 나갔거나, x또는y값 차이의 절댓값이 300을 넘어서면
        -- 타겟을 nil로 초기화하고 200 범위 내에서 타겟을 설정
        elseif (ai.GetTargetUnit()==nil)
               or (enemy.field.GetUnit(ai.GetTargetUnitID())==nil)
               or (math.abs(enemy.x-enemy.field.GetUnit(ai.GetTargetUnitID()).x) >= 300) 
               or (math.abs(enemy.y-enemy.field.GetUnit(ai.GetTargetUnitID()).y) >= 300) then
            
            ai.SetFollowTarget(false) --타겟이 사라졌으면 추적을 비활성화 
            ai.SetTargetUnit(nil)
            ai.SetNearTarget(0,200)

            -- 주변을 탐색 후 타겟을 찾았으면(nil이 아니면), 추적을 활성화(true), 메세지출력
            if ai.GetTargetUnit() ~= nil then 
                ai.SetFollowTarget(true) 
            end
        end
        
        --타겟이 있으면 타겟 방향을 향해 10번 스킬을 발사
        if ai.GetTargetUnit() ~= nil then
            ai.UseSkill(10)
        end
        
        --타겟이 없을경우 예외처리
        if ai.GetTargetUnit() == nil then
            return
        end
        
    end
    
    if (event == AI_ATTACKED) then -- 몬스터가 공격을 받을때마다 실행되는 이벤트
        --공격한 유닛이 없을경우 예외처리
        if ai.GetAttackedUnit() == nil then
            return
        else
            --기존타겟유닛과 공격유닛이 같지 않을때, 공격을 한 유닛을 타겟으로 지정 또는 변경하고 추격
            if ai.GetTargetUnit() ~= ai.GetAttackedUnit() then 
                ai.SetTargetUnit(ai.GetAttackedUnit())
                ai.SetFollowTarget(true)
                enemy.say('새로운 공격자를 추적한다..')
            end
            
            -- 몬스터가 공격당할시 10% 확률로 짱짱쌘 5번 공격 기술을 시전하고 서버전체에 메세지 출력
            if math.random(0,99) <= 9 then
                ai.UseSkill(5)
                Server.SendCenterLabel('<color=#FF0000>크롸롸!!</color>\n멍청한 보스 배던이 울부짖습니다!')
            end
        end
    end
        
end