-- --똥 AI
-- function forward(enemy,ai,event,data)
--     if(event == AI_INIT) then
--         ai.customData.timer = 0
--     end
--     if(event == AI_UPDATE) then
--         ai.SetTargetUnit(nil)
--         if(enemy.y <= -(32 * 19)) then
--             local randomx = 32 * rand(2,38)
--             local randomy = 32 * rand(0,10)
--             enemy.ShowAnimation(12)
--             enemy.SpawnAt(randomx,randomy)
--         end
--     end
--     if(event == AI_DEAD) then
--         enemy.ShowAnimation(12)
--     end

-- end
-- Server.SetMonsterAI(4,forward)
-- Server.SetMonsterAI(7,forward)
-- Server.SetMonsterAI(8,forward)
-- Server.SetMonsterAI(9,forward)


-- --아이템 AI
-- function ItemAi(enemy,ai,event,data)
--     if(event == AI_DEAD) then
--         ai.customData.random = rand(1,1)
--         if(ai.GetAttackedUnit() ~= nil) then
--             if(ai.customData.random == 0) then
--                 ai.GetAttackedUnit().AddBuff(3)
--             elseif(ai.customData.random == 1) then
--                 enemy.ShowAnimation(11)
--                 for idx,enemyUnit in ipairs(enemy.field.units) do
--                     if(enemyUnit.type == 2) then
--                         enemyUnit.AddDamage(1000)
--                     end
--                 end
--             end
--         end
--     end
-- end
-- Server.SetMonsterAI(6,ItemAi)

function CustomKnockback(a, b,distance)
    local tempDis = distance

    if a.dirX ~= 0 then
        -- 몬스터일경우(똥,아이템상자) 넉백X
        if (b.type == 2) then
            return;
        end
        -- 좌 또는 우 방향일 때
        b.dirX = a.dirX * -1;
        b.dirY = 0;
        tempDis = tempDis 
    end

	-- 플레이어 유닛 위치 정보 갱신
	a.SendUpdated(true)
	b.SendUpdated(true)
	
    -- 넉백 실시
	b.MakeKnockback(tempDis, 0.1)
end